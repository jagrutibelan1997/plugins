<?php
/**
 * Leads Management Data Layer for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Leads
 */
class Publication_CRM_Leads {

	/**
	 * Database handler.
	 *
	 * @var Publication_CRM_Database
	 */
	private $db;

	/**
	 * Constructor.
	 *
	 * @param Publication_CRM_Database $db Database instance.
	 */
	public function __construct( Publication_CRM_Database $db ) {
		$this->db = $db;
	}

	/**
	 * Create a new lead record.
	 *
	 * @param array $data Sanitized lead data.
	 * @return int|false Lead ID on success, false on failure.
	 */
	public function create_lead( array $data ) {
		global $wpdb;

		$table_name = $this->db->get_leads_table();
		$now        = current_time( 'mysql' );

		$defaults = array(
			'full_name'    => '',
			'email'        => '',
			'phone'        => '',
			'company'      => '',
			'enquiry_type' => 'General Enquiry',
			'subject'      => '',
			'message'      => '',
			'source'       => 'Website',
			'status'       => 'New',
			'created_at'   => $now,
			'updated_at'   => $now,
		);

		$lead_data = wp_parse_args( $data, $defaults );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			$table_name,
			array(
				'full_name'    => $lead_data['full_name'],
				'email'        => $lead_data['email'],
				'phone'        => $lead_data['phone'],
				'company'      => $lead_data['company'],
				'enquiry_type' => $lead_data['enquiry_type'],
				'subject'      => $lead_data['subject'],
				'message'      => $lead_data['message'],
				'source'       => $lead_data['source'],
				'status'       => $lead_data['status'],
				'created_at'   => $lead_data['created_at'],
				'updated_at'   => $lead_data['updated_at'],
			),
			array(
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
			)
		);

		if ( false === $result ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Get a single lead by ID.
	 *
	 * @param int $id Lead ID.
	 * @return object|null
	 */
	public function get_lead( $id ) {
		global $wpdb;

		$id         = absint( $id );
		$table_name = $this->db->get_leads_table();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE id = %d LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$id
			)
		);
	}

	/**
	 * Get leads with search, filters, sorting, and pagination.
	 *
	 * @param array $args Query parameters.
	 * @return array Array containing 'items' and 'total'.
	 */
	public function get_leads( array $args = array() ) {
		global $wpdb;

		$table_name = $this->db->get_leads_table();

		$defaults = array(
			'search'       => '',
			'status'       => '',
			'enquiry_type' => '',
			'orderby'      => 'created_at',
			'order'        => 'DESC',
			'per_page'     => 20,
			'paged'        => 1,
		);

		$params = wp_parse_args( $args, $defaults );

		$where_clauses = array( '1=1' );
		$query_params  = array();

		// Search term (name, email, company, subject).
		if ( ! empty( $params['search'] ) ) {
			$search_like = '%' . $wpdb->esc_like( $params['search'] ) . '%';
			$where_clauses[] = '(full_name LIKE %s OR email LIKE %s OR company LIKE %s OR subject LIKE %s)';
			$query_params[]  = $search_like;
			$query_params[]  = $search_like;
			$query_params[]  = $search_like;
			$query_params[]  = $search_like;
		}

		// Status filter.
		if ( ! empty( $params['status'] ) ) {
			$where_clauses[] = 'status = %s';
			$query_params[]  = $params['status'];
		}

		// Enquiry type filter.
		if ( ! empty( $params['enquiry_type'] ) ) {
			$where_clauses[] = 'enquiry_type = %s';
			$query_params[]  = $params['enquiry_type'];
		}

		$where_sql = implode( ' AND ', $where_clauses );

		// Whitelist orderby.
		$allowed_orderby = array(
			'id'           => 'id',
			'full_name'    => 'full_name',
			'email'        => 'email',
			'company'      => 'company',
			'enquiry_type' => 'enquiry_type',
			'status'       => 'status',
			'created_at'   => 'created_at',
		);
		$orderby = isset( $allowed_orderby[ $params['orderby'] ] ) ? $allowed_orderby[ $params['orderby'] ] : 'created_at';
		$order   = 'ASC' === strtoupper( $params['order'] ) ? 'ASC' : 'DESC';

		$per_page = max( 1, absint( $params['per_page'] ) );
		$paged    = max( 1, absint( $params['paged'] ) );
		$offset   = ( $paged - 1 ) * $per_page;

		// Get total count first.
		if ( ! empty( $query_params ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE {$where_sql}", $query_params ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		}

		// Query items with LIMIT and OFFSET.
		$items_params = array_merge( $query_params, array( $per_page, $offset ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
		$items = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d", $items_params )
		);

		return array(
			'items'    => $items ? $items : array(),
			'total'    => $total,
			'per_page' => $per_page,
			'paged'    => $paged,
			'pages'    => ceil( $total / $per_page ),
		);
	}

	/**
	 * Update lead status.
	 *
	 * @param int    $id     Lead ID.
	 * @param string $status New status.
	 * @return bool
	 */
	public function update_status( $id, $status ) {
		global $wpdb;

		$id             = absint( $id );
		$allowed_states = Publication_CRM_Security::get_allowed_statuses();

		if ( ! array_key_exists( $status, $allowed_states ) ) {
			return false;
		}

		$table_name = $this->db->get_leads_table();
		$now        = current_time( 'mysql' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$updated = $wpdb->update(
			$table_name,
			array(
				'status'     => $status,
				'updated_at' => $now,
			),
			array( 'id' => $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		return false !== $updated;
	}

	/**
	 * Delete a lead record.
	 *
	 * @param int $id Lead ID.
	 * @return bool
	 */
	public function delete_lead( $id ) {
		global $wpdb;

		$id         = absint( $id );
		$table_name = $this->db->get_leads_table();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$deleted = $wpdb->delete(
			$table_name,
			array( 'id' => $id ),
			array( '%d' )
		);

		return false !== $deleted;
	}

	/**
	 * Get lead counts grouped by status for Dashboard statistics.
	 *
	 * @return array
	 */
	public function get_counts_by_status() {
		global $wpdb;

		$table_name = $this->db->get_leads_table();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$results = $wpdb->get_results(
			"SELECT status, COUNT(*) as count FROM {$table_name} GROUP BY status" // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		);

		$counts = array(
			'Total'     => 0,
			'New'       => 0,
			'Contacted' => 0,
			'Qualified' => 0,
			'Converted' => 0,
			'Lost'      => 0,
		);

		if ( $results ) {
			foreach ( $results as $row ) {
				$status = $row->status;
				$count  = (int) $row->count;

				if ( isset( $counts[ $status ] ) ) {
					$counts[ $status ] = $count;
				}
				$counts['Total'] += $count;
			}
		}

		return $counts;
	}

	/**
	 * Get recent leads for dashboard.
	 *
	 * @param int $limit Number of recent leads.
	 * @return array
	 */
	public function get_recent_leads( $limit = 5 ) {
		global $wpdb;

		$limit      = absint( $limit );
		$table_name = $this->db->get_leads_table();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			)
		);

		return $results ? $results : array();
	}
}
