<?php
/**
 * Contacts Management Data Layer for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Contacts
 */
class Publication_CRM_Contacts {

	/**
	 * Database handler.
	 *
	 * @var Publication_CRM_Database
	 */
	private $db;

	/**
	 * Constructor.
	 *
	 * @param Publication_CRM_Database $db Database instance.
	 */
	public function __construct( Publication_CRM_Database $db ) {
		$this->db = $db;
	}

	/**
	 * Sync contact from a lead submission.
	 *
	 * @param object|array $lead Lead data.
	 * @return int Contact ID.
	 */
	public function sync_from_lead( $lead ) {
		global $wpdb;

		$table_name = $this->db->get_contacts_table();
		$lead       = (object) $lead;
		$now        = current_time( 'mysql' );

		// Check if contact already exists by email.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, total_leads FROM {$table_name} WHERE email = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$lead->email
			)
		);

		if ( $existing ) {
			// Update contact info and increment total leads count.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
			$wpdb->update(
				$table_name,
				array(
					'full_name'   => ! empty( $lead->full_name ) ? $lead->full_name : '',
					'phone'       => ! empty( $lead->phone ) ? $lead->phone : '',
					'company'     => ! empty( $lead->company ) ? $lead->company : '',
					'total_leads' => $existing->total_leads + 1,
					'updated_at'  => $now,
				),
				array( 'id' => $existing->id ),
				array( '%s', '%s', '%s', '%d', '%s' ),
				array( '%d' )
			);

			return (int) $existing->id;
		}

		// Insert new contact.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$wpdb->insert(
			$table_name,
			array(
				'full_name'   => ! empty( $lead->full_name ) ? $lead->full_name : '',
				'email'       => $lead->email,
				'phone'       => ! empty( $lead->phone ) ? $lead->phone : '',
				'company'     => ! empty( $lead->company ) ? $lead->company : '',
				'total_leads' => 1,
				'status'      => 'Active',
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);

		return (int) $wpdb->insert_id;
	}

	/**
	 * Get contacts list with search, sorting, and pagination.
	 *
	 * @param array $args Query parameters.
	 * @return array
	 */
	public function get_contacts( array $args = array() ) {
		global $wpdb;

		$table_name = $this->db->get_contacts_table();

		$defaults = array(
			'search'   => '',
			'orderby'  => 'created_at',
			'order'    => 'DESC',
			'per_page' => 20,
			'paged'    => 1,
		);

		$params = wp_parse_args( $args, $defaults );

		$where_clauses = array( '1=1' );
		$query_params  = array();

		if ( ! empty( $params['search'] ) ) {
			$search_like = '%' . $wpdb->esc_like( $params['search'] ) . '%';
			$where_clauses[] = '(full_name LIKE %s OR email LIKE %s OR company LIKE %s)';
			$query_params[]  = $search_like;
			$query_params[]  = $search_like;
			$query_params[]  = $search_like;
		}

		$where_sql = implode( ' AND ', $where_clauses );

		$allowed_orderby = array(
			'id'          => 'id',
			'full_name'   => 'full_name',
			'email'       => 'email',
			'company'     => 'company',
			'total_leads' => 'total_leads',
			'created_at'  => 'created_at',
		);
		$orderby = isset( $allowed_orderby[ $params['orderby'] ] ) ? $allowed_orderby[ $params['orderby'] ] : 'created_at';
		$order   = 'ASC' === strtoupper( $params['order'] ) ? 'ASC' : 'DESC';

		$per_page = max( 1, absint( $params['per_page'] ) );
		$paged    = max( 1, absint( $params['paged'] ) );
		$offset   = ( $paged - 1 ) * $per_page;

		// Get total count first.
		if ( ! empty( $query_params ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE {$where_sql}", $query_params ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		}

		// Query items with LIMIT and OFFSET.
		$items_params = array_merge( $query_params, array( $per_page, $offset ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
		$items = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table_name} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d", $items_params )
		);

		return array(
			'items'    => $items ? $items : array(),
			'total'    => $total,
			'per_page' => $per_page,
			'paged'    => $paged,
			'pages'    => ceil( $total / $per_page ),
		);
	}

	/**
	 * Get total count of contacts.
	 *
	 * @return int
	 */
	public function get_total_count() {
		global $wpdb;

		$table_name = $this->db->get_contacts_table();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
}
