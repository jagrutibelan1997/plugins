<?php
/**
 * Admin Controller for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Admin
 */
class Publication_CRM_Admin {

	/**
	 * Leads handler.
	 *
	 * @var Publication_CRM_Leads
	 */
	private $leads;

	/**
	 * Contacts handler.
	 *
	 * @var Publication_CRM_Contacts
	 */
	private $contacts;

	/**
	 * Constructor.
	 *
	 * @param Publication_CRM_Leads    $leads    Leads instance.
	 * @param Publication_CRM_Contacts $contacts Contacts instance.
	 */
	public function __construct( Publication_CRM_Leads $leads, Publication_CRM_Contacts $contacts ) {
		$this->leads    = $leads;
		$this->contacts = $contacts;

		$this->init_hooks();
	}

	/**
	 * Register admin hooks.
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'register_admin_menus' ) );
		add_action( 'admin_init', array( $this, 'handle_admin_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Register CRM admin menus.
	 */
	public function register_admin_menus() {
		// Top Level Menu: CRM.
		add_menu_page(
			__( 'Publication CRM', 'publication-crm' ),
			__( 'CRM', 'publication-crm' ),
			Publication_CRM_Security::REQUIRED_CAPABILITY,
			'publication-crm',
			array( $this, 'render_dashboard_page' ),
			'dashicons-id-alt',
			30
		);

		// Submenu: Dashboard.
		add_submenu_page(
			'publication-crm',
			__( 'CRM Dashboard', 'publication-crm' ),
			__( 'Dashboard', 'publication-crm' ),
			Publication_CRM_Security::REQUIRED_CAPABILITY,
			'publication-crm',
			array( $this, 'render_dashboard_page' )
		);

		// Submenu: Leads.
		add_submenu_page(
			'publication-crm',
			__( 'CRM Leads', 'publication-crm' ),
			__( 'Leads', 'publication-crm' ),
			Publication_CRM_Security::REQUIRED_CAPABILITY,
			'publication-crm-leads',
			array( $this, 'render_leads_page' )
		);

		// Submenu: Contacts.
		add_submenu_page(
			'publication-crm',
			__( 'CRM Contacts', 'publication-crm' ),
			__( 'Contacts', 'publication-crm' ),
			Publication_CRM_Security::REQUIRED_CAPABILITY,
			'publication-crm-contacts',
			array( $this, 'render_contacts_page' )
		);

		// Submenu: Settings.
		add_submenu_page(
			'publication-crm',
			__( 'CRM Settings', 'publication-crm' ),
			__( 'Settings', 'publication-crm' ),
			Publication_CRM_Security::REQUIRED_CAPABILITY,
			'publication-crm-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/**
	 * Enqueue admin scripts & styles on CRM screens.
	 *
	 * @param string $hook Admin page hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( strpos( $hook, 'publication-crm' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'publication-crm-admin',
			PUBLICATION_CRM_URL . 'admin/css/crm-admin.css',
			array(),
			PUBLICATION_CRM_VERSION
		);

		wp_enqueue_script(
			'publication-crm-admin',
			PUBLICATION_CRM_URL . 'admin/js/crm-admin.js',
			array(),
			PUBLICATION_CRM_VERSION,
			true
		);
	}

	/**
	 * Process form submissions and admin mutations.
	 */
	public function handle_admin_actions() {
		if ( ! Publication_CRM_Security::current_user_can_manage() ) {
			return;
		}

		$page   = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
		$action = isset( $_REQUEST['action'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ) : '';

		if ( 'publication-crm-leads' === $page ) {
			// Update status action.
			if ( 'update_status' === $action && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
				check_admin_referer( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' );

				$lead_id    = isset( $_POST['lead_id'] ) ? absint( $_POST['lead_id'] ) : 0;
				$new_status = isset( $_POST['new_status'] ) ? sanitize_text_field( wp_unslash( $_POST['new_status'] ) ) : '';

				if ( $lead_id && $new_status ) {
					$this->leads->update_status( $lead_id, $new_status );
				}

				wp_safe_redirect(
					add_query_arg(
						array(
							'page'    => 'publication-crm-leads',
							'action'  => 'view',
							'id'      => $lead_id,
							'updated' => 1,
						),
						admin_url( 'admin.php' )
					)
				);
				exit;
			}

			// Delete lead action.
			if ( 'delete' === $action ) {
				check_admin_referer( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' );

				$lead_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
				if ( $lead_id ) {
					$this->leads->delete_lead( $lead_id );
				}

				wp_safe_redirect(
					add_query_arg(
						array(
							'page'    => 'publication-crm-leads',
							'deleted' => 1,
						),
						admin_url( 'admin.php' )
					)
				);
				exit;
			}
		}

		if ( 'publication-crm-settings' === $page && 'save_settings' === $action && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
			check_admin_referer( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' );

			$notification_email = isset( $_POST['publication_crm_notification_email'] ) ? sanitize_email( wp_unslash( $_POST['publication_crm_notification_email'] ) ) : '';
			$enable_honeypot    = ! empty( $_POST['publication_crm_enable_honeypot'] ) ? '1' : '0';
			$clean_uninstall    = ! empty( $_POST['publication_crm_clean_on_uninstall'] ) ? '1' : '0';

			update_option( 'publication_crm_notification_email', $notification_email );
			update_option( 'publication_crm_enable_honeypot', $enable_honeypot );
			update_option( 'publication_crm_clean_on_uninstall', $clean_uninstall );

			wp_safe_redirect(
				add_query_arg(
					array(
						'page'             => 'publication-crm-settings',
						'settings_updated' => 1,
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}
	}

	/**
	 * Render Dashboard page.
	 */
	public function render_dashboard_page() {
		require_once PUBLICATION_CRM_DIR . 'admin/dashboard.php';
	}

	/**
	 * Render Leads page (either list or detail).
	 */
	public function render_leads_page() {
		$action = isset( $_GET['action'] ) ? sanitize_text_field( wp_unslash( $_GET['action'] ) ) : 'list';

		if ( 'view' === $action ) {
			require_once PUBLICATION_CRM_DIR . 'admin/lead-detail.php';
		} else {
			require_once PUBLICATION_CRM_DIR . 'admin/leads.php';
		}
	}

	/**
	 * Render Contacts page.
	 */
	public function render_contacts_page() {
		require_once PUBLICATION_CRM_DIR . 'admin/contacts.php';
	}

	/**
	 * Render Settings page.
	 */
	public function render_settings_page() {
		require_once PUBLICATION_CRM_DIR . 'admin/settings.php';
	}
}
