<?php
/**
 * Security and validation utilities for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Security
 */
class Publication_CRM_Security {

	/**
	 * Nonce action for public contact form.
	 */
	const NONCE_ACTION_CONTACT = 'publication_crm_contact_action';

	/**
	 * Nonce field name for public contact form.
	 */
	const NONCE_NAME_CONTACT = 'publication_crm_contact_nonce';

	/**
	 * Nonce action for admin operations.
	 */
	const NONCE_ACTION_ADMIN = 'publication_crm_admin_action';

	/**
	 * Required capability for CRM admin access.
	 */
	const REQUIRED_CAPABILITY = 'manage_options';

	/**
	 * Allowed enquiry types whitelist.
	 *
	 * @return array
	 */
	public static function get_allowed_enquiry_types() {
		return array(
			'General Enquiry' => __( 'General Enquiry', 'publication-crm' ),
			'Advertising'     => __( 'Advertising', 'publication-crm' ),
			'Partnership'     => __( 'Partnership', 'publication-crm' ),
			'Editorial'       => __( 'Editorial', 'publication-crm' ),
			'Feedback'        => __( 'Feedback', 'publication-crm' ),
			'Other'           => __( 'Other', 'publication-crm' ),
		);
	}

	/**
	 * Allowed lead statuses whitelist.
	 *
	 * @return array
	 */
	public static function get_allowed_statuses() {
		return array(
			'New'       => __( 'New', 'publication-crm' ),
			'Contacted' => __( 'Contacted', 'publication-crm' ),
			'Qualified' => __( 'Qualified', 'publication-crm' ),
			'Converted' => __( 'Converted', 'publication-crm' ),
			'Lost'      => __( 'Lost', 'publication-crm' ),
		);
	}

	/**
	 * Verify admin capability.
	 *
	 * @return bool
	 */
	public static function current_user_can_manage() {
		return current_user_can( self::REQUIRED_CAPABILITY );
	}

	/**
	 * Sanitize and validate contact form submission data.
	 *
	 * @param array $raw_data Raw input array.
	 * @return array|WP_Error Array of sanitized data or WP_Error on failure.
	 */
	public static function validate_and_sanitize_lead_input( $raw_data ) {
		$errors = new WP_Error();

		// Check Honeypot field (bots usually fill this hidden field).
		$honeypot_enabled = get_option( 'publication_crm_enable_honeypot', '1' );
		if ( '1' === $honeypot_enabled && ! empty( $raw_data['website_url_hp'] ) ) {
			// Silently fail spam bots.
			$errors->add( 'spam_detected', __( 'Submission rejected.', 'publication-crm' ) );
			return $errors;
		}

		// Full Name (required).
		$full_name = isset( $raw_data['full_name'] ) ? sanitize_text_field( wp_unslash( $raw_data['full_name'] ) ) : '';
		if ( empty( $full_name ) ) {
			$errors->add( 'full_name_required', __( 'Full Name is required.', 'publication-crm' ) );
		}

		// Email Address (required & valid).
		$email = isset( $raw_data['email'] ) ? sanitize_email( wp_unslash( $raw_data['email'] ) ) : '';
		if ( empty( $email ) || ! is_email( $email ) ) {
			$errors->add( 'email_invalid', __( 'A valid Email Address is required.', 'publication-crm' ) );
		}

		// Phone Number (optional).
		$phone = isset( $raw_data['phone'] ) ? sanitize_text_field( wp_unslash( $raw_data['phone'] ) ) : '';

		// Company / Organization (optional).
		$company = isset( $raw_data['company'] ) ? sanitize_text_field( wp_unslash( $raw_data['company'] ) ) : '';

		// Enquiry Type (required & whitelisted).
		$allowed_types = self::get_allowed_enquiry_types();
		$enquiry_type  = isset( $raw_data['enquiry_type'] ) ? sanitize_text_field( wp_unslash( $raw_data['enquiry_type'] ) ) : '';
		if ( empty( $enquiry_type ) || ! array_key_exists( $enquiry_type, $allowed_types ) ) {
			$errors->add( 'enquiry_type_invalid', __( 'Please select a valid Enquiry Type.', 'publication-crm' ) );
		}

		// Subject (required).
		$subject = isset( $raw_data['subject'] ) ? sanitize_text_field( wp_unslash( $raw_data['subject'] ) ) : '';
		if ( empty( $subject ) ) {
			$errors->add( 'subject_required', __( 'Subject is required.', 'publication-crm' ) );
		}

		// Message (required).
		$message = isset( $raw_data['message'] ) ? sanitize_textarea_field( wp_unslash( $raw_data['message'] ) ) : '';
		if ( empty( $message ) ) {
			$errors->add( 'message_required', __( 'Message is required.', 'publication-crm' ) );
		}

		if ( $errors->has_errors() ) {
			return $errors;
		}

		return array(
			'full_name'    => $full_name,
			'email'        => $email,
			'phone'        => $phone,
			'company'      => $company,
			'enquiry_type' => $enquiry_type,
			'subject'      => $subject,
			'message'      => $message,
			'source'       => 'Website',
			'status'       => 'New',
		);
	}
}
