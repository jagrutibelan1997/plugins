<?php
/**
 * Database management for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Database
 */
class Publication_CRM_Database {

	/**
	 * Database schema version.
	 */
	const DB_VERSION = '1.0.0';

	/**
	 * Leads table name.
	 *
	 * @var string
	 */
	private $leads_table;

	/**
	 * Contacts table name.
	 *
	 * @var string
	 */
	private $contacts_table;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->leads_table    = $wpdb->prefix . 'publication_crm_leads';
		$this->contacts_table = $wpdb->prefix . 'publication_crm_contacts';
	}

	/**
	 * Get leads table name.
	 *
	 * @return string
	 */
	public function get_leads_table() {
		return $this->leads_table;
	}

	/**
	 * Get contacts table name.
	 *
	 * @return string
	 */
	public function get_contacts_table() {
		return $this->contacts_table;
	}

	/**
	 * Create or upgrade custom CRM tables using dbDelta.
	 */
	public function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		// Leads table schema.
		$leads_sql = "CREATE TABLE {$this->leads_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			full_name VARCHAR(255) NOT NULL,
			email VARCHAR(255) NOT NULL,
			phone VARCHAR(50) DEFAULT '',
			company VARCHAR(255) DEFAULT '',
			enquiry_type VARCHAR(50) NOT NULL,
			subject VARCHAR(255) NOT NULL,
			message LONGTEXT NOT NULL,
			source VARCHAR(50) NOT NULL DEFAULT 'Website',
			status VARCHAR(50) NOT NULL DEFAULT 'New',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY email_idx (email),
			KEY status_idx (status),
			KEY enquiry_type_idx (enquiry_type),
			KEY created_at_idx (created_at)
		) {$charset_collate};";

		// Contacts table schema.
		$contacts_sql = "CREATE TABLE {$this->contacts_table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			full_name VARCHAR(255) NOT NULL,
			email VARCHAR(255) NOT NULL,
			phone VARCHAR(50) DEFAULT '',
			company VARCHAR(255) DEFAULT '',
			total_leads INT(11) UNSIGNED NOT NULL DEFAULT 1,
			status VARCHAR(50) NOT NULL DEFAULT 'Active',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email_unique (email)
		) {$charset_collate};";

		dbDelta( $leads_sql );
		dbDelta( $contacts_sql );

		update_option( 'publication_crm_db_version', self::DB_VERSION );
	}
}
