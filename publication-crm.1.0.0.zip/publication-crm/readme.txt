=== Publication CRM ===
Contributors: jagrutibelan
Tags: crm, contact form, customer relationship management, contacts, leads
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

High-performance, VIP-compliant custom CRM and contact form system for Publication websites.

== Description ==

Publication CRM is a high-performance, VIP-compliant custom customer relationship management (CRM) and contact form system designed specifically for digital publications, online magazines, newsrooms, and media businesses.

Unlike bloated all-in-one CRM solutions that introduce heavy external dependencies and slow down site performance, Publication CRM provides an accessible, lightweight inquiry capture form coupled with a clean, responsive editorial administration dashboard. It captures incoming inquiries directly into custom database tables, aggregates communication history by contact email, and keeps editorial teams notified immediately.

== Features ==

* **Centralized Contact Management**: Automatically aggregates repeat inquiries by contact email, tracking cumulative lead volume and communication history without duplicating records.
* **CRM Dashboard**: Real-time KPI metrics (Total, New, Contacted, Qualified, Converted, and Lost) alongside a table of recent inquiries with relative timestamps.
* **Accessible Contact Form**: Semantic HTML5 frontend contact form embeddable anywhere using the `[publication_contact_form]` shortcode, complete with accessible labels, keyboard navigation, and live ARIA alert feedback.
* **Dual Submission Handlers**: Asynchronous AJAX form processing with automatic non-AJAX POST fallback for environments without JavaScript enabled.
* **Editorial Inquiry Categorization**: Built-in routing for Editorial pitches, Advertising inquiries, Strategic Partnerships, Feedback, and General questions.
* **Real-Time Email Notifications**: Immediate email alerts dispatched to configured editorial or business desks whenever a visitor submits an inquiry.
* **Built-in Spam Protection**: Silent honeypot bot trap prevents spam submissions without annoying users with intrusive third-party captchas or trackers.
* **Administrative Search & Filtering**: Fast search across contact names, emails, companies, and subjects, combined with status and category filtering.
* **Lead Detail Management**: Dedicated admin view to inspect full message bodies and transition leads through the status lifecycle.
* **Secure WordPress VIP Standards**: Full nonce verification, input sanitization, output escaping, parameterized SQL queries, and strict administrator capability checks (`manage_options`).
* **Clean & Safe Uninstallation**: Cleanly preserves user data by default, with an optional hard-reset toggle in settings to drop custom tables on uninstall.
* **100% Internationalized (i18n)**: All UI strings and notices are localized with complete text domain support and an included POT translation catalog.

== Installation ==

1. Upload the `publication-crm` plugin folder to the `/wp-content/plugins/` directory, or install directly through the WordPress Plugins dashboard (`Plugins > Add New`).
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Upon activation, custom high-efficiency database tables are created automatically, and a default `/contact/` page containing the shortcode `[publication_contact_form]` is generated if it does not already exist.
4. Navigate to **CRM > Settings** in the WordPress admin menu to configure your email notification address and spam protection preferences.
5. Embed the shortcode `[publication_contact_form]` on any page or post to display the contact form.

== Frequently Asked Questions ==

= Where can I access Publication CRM in the WordPress admin? =

Publication CRM adds a top-level **CRM** menu in the WordPress administration sidebar, containing sections for **Dashboard**, **Leads**, **Contacts**, and **Settings**.

= How do I embed the contact form on my website? =

Place the shortcode `[publication_contact_form]` on any WordPress page, post, or block editor shortcode block. Upon plugin activation, a `/contact/` page is also generated automatically if it did not previously exist.

= Does Publication CRM store contacts in WordPress? =

Yes. All inquiries and contact profiles are stored securely in your WordPress database in dedicated, optimized tables (`wp_publication_crm_leads` and `wp_publication_crm_contacts`). Contact profiles are automatically created or synchronized based on the submitter's email address.

= Can I configure who receives lead notification alerts? =

Yes. Navigate to **CRM > Settings** in your WordPress admin menu and enter the email address that should receive new submission alerts. If left blank, notifications default to your WordPress site administrator email.

= Is the plugin compatible with WordPress VIP standards? =

Yes. Publication CRM is developed following WordPress VIP best practices: strict input sanitization, contextual output escaping, prepared database queries via `$wpdb->prepare()`, nonce verification on all mutation requests, user capability checks (`manage_options`), and zero external render-blocking scripts or stylesheets.

= Does Publication CRM track user data or load external scripts? =

No. Publication CRM runs entirely on your server, loads zero external third-party assets or CDNs, and performs no remote tracking or telemetry.

= What happens to CRM data when the plugin is deleted? =

By default, all leads, contacts, and configuration options are preserved to prevent accidental data loss. If you wish to delete all data upon plugin removal, enable the "Uninstall Cleanup" option in **CRM > Settings** before deleting the plugin.

== Screenshots ==

1. CRM Dashboard overview displaying total leads, status breakdown, and recent inquiries.
2. Filterable leads list with status badges, date stamps, and search capabilities.
3. Lead detail page with full inquiry message body and status update workflow.
4. Contacts directory tracking total inquiries per person or company.
5. Settings screen to manage email alerts and honeypot protection.
6. Frontend contact form with validation and accessible UI styling.

== Changelog ==

= 1.0.0 =
* Initial public release approved for the WordPress.org plugin directory.
* Added high-efficiency custom database schema for leads and contacts tracking.
* Added accessible frontend contact form with AJAX submission and non-AJAX POST fallback.
* Added CRM dashboard with real-time status KPI metrics and recent inquiries overview.
* Added leads management interface with search, status filtering, category filtering, and pagination.
* Added lead detail view with complete message body and status transition workflow.
* Added contacts directory aggregating multiple inquiries by email address.
* Added instant email alerts dispatched via wp_mail to configured editorial or admin address.
* Added built-in silent honeypot spam protection.
* Added settings screen for alert email configuration and optional uninstallation data cleanup.
* Added full internationalization support with POT translation catalog.

== Upgrade Notice ==

= 1.0.0 =
Initial release of Publication CRM.
