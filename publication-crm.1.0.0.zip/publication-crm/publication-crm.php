<?php
/**
 * Plugin Name: Publication CRM
 * Description: High-performance, VIP-compliant custom CRM and contact form system for Publication websites.
 * Version: 1.0.0
 * Author: Jagruti Belan
 * Author URI: https://profiles.wordpress.org/jagrutibelan
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: publication-crm
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} 

// Define Plugin Constants.
define( 'PUBLICATION_CRM_VERSION', '1.0.0' );
define( 'PUBLICATION_CRM_DIR', plugin_dir_path( __FILE__ ) );
define( 'PUBLICATION_CRM_URL', plugin_dir_url( __FILE__ ) );
define( 'PUBLICATION_CRM_BASENAME', plugin_basename( __FILE__ ) );

// Include Core Classes.
require_once PUBLICATION_CRM_DIR . 'includes/class-crm-database.php';
require_once PUBLICATION_CRM_DIR . 'includes/class-crm-security.php';
require_once PUBLICATION_CRM_DIR . 'includes/class-crm-leads.php';
require_once PUBLICATION_CRM_DIR . 'includes/class-crm-contacts.php';
require_once PUBLICATION_CRM_DIR . 'includes/class-crm-admin.php';
require_once PUBLICATION_CRM_DIR . 'public/class-contact-form.php';

/**
 * Main Publication CRM Plugin Class.
 */
final class Publication_CRM {

	/**
	 * Singleton instance.
	 *
	 * @var Publication_CRM|null
	 */
	private static $instance = null;

	/**
	 * Database handler.
	 *
	 * @var Publication_CRM_Database
	 */
	public $database;

	/**
	 * Leads handler.
	 *
	 * @var Publication_CRM_Leads
	 */
	public $leads;

	/**
	 * Contacts handler.
	 *
	 * @var Publication_CRM_Contacts
	 */
	public $contacts;

	/**
	 * Admin handler.
	 *
	 * @var Publication_CRM_Admin
	 */
	public $admin;

	/**
	 * Frontend contact form handler.
	 *
	 * @var Publication_CRM_Contact_Form
	 */
	public $contact_form;

	/**
	 * Get singleton instance.
	 *
	 * @return Publication_CRM
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init_components();
		$this->init_hooks();
	}

	/**
	 * Initialize components.
	 */
	private function init_components() {
		$this->database     = new Publication_CRM_Database();
		$this->leads        = new Publication_CRM_Leads( $this->database );
		$this->contacts     = new Publication_CRM_Contacts( $this->database );
		$this->admin        = new Publication_CRM_Admin( $this->leads, $this->contacts );
		$this->contact_form = new Publication_CRM_Contact_Form( $this->leads, $this->contacts );
	}

	/**
	 * Hook registrations.
	 */
	private function init_hooks() {
		register_activation_hook( __FILE__, array( $this, 'activate' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

		add_filter( 'plugin_action_links_' . PUBLICATION_CRM_BASENAME, array( $this, 'add_plugin_action_links' ) );
	}

	/**
	 * Add custom action links on the Plugins list screen.
	 *
	 * @param array $links Array of plugin action links.
	 * @return array
	 */
	public function add_plugin_action_links( $links ) {
		$custom_links = array(
			'<a href="' . esc_url( admin_url( 'admin.php?page=publication-crm-settings' ) ) . '">' . esc_html__( 'Settings', 'publication-crm' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=publication-crm' ) ) . '">' . esc_html__( 'Dashboard', 'publication-crm' ) . '</a>',
		);
		return array_merge( $custom_links, $links );
	}

	/**
	 * Plugin activation routine.
	 */
	public function activate() {
		// Run database migrations.
		$this->database->create_tables();

		// Create default /contact/ page if it does not exist.
		$this->create_default_contact_page();

		// Flush rewrite rules for newly created page.
		flush_rewrite_rules();
	}

	/**
	 * Plugin deactivation routine.
	 */
	public function deactivate() {
		flush_rewrite_rules();
	}

	/**
	 * Ensure the /contact/ page exists with proper shortcode.
	 */
	public function create_default_contact_page() {
		$page = get_page_by_path( 'contact' );

		if ( ! $page ) {
			$page_data = array(
				'post_title'     => __( 'Contact Us', 'publication-crm' ),
				'post_name'      => 'contact',
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
				'post_content'   => "<!-- wp:paragraph -->\n<p>" . __( 'Have an editorial tip, partnership inquiry, advertising question, or feedback for our team? Please select the appropriate category below and send us a message. Our team typically responds within one business day.', 'publication-crm' ) . "</p>\n<!-- /wp:paragraph -->\n\n[publication_contact_form]",
			);

			wp_insert_post( $page_data );
		}
	}
}

/**
 * Access the main plugin instance.
 *
 * @return Publication_CRM
 */
function publication_crm() {
	return Publication_CRM::get_instance();
}

// Bootstrap plugin.
publication_crm();
