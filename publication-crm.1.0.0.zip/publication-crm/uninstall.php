<?php
/**
 * Uninstall Publication CRM.
 *
 * Triggered when plugin is deleted via the WordPress Admin.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// In standard VIP guidelines, data is preserved or cleaned up only if explicitly configured.
// Optional: Drop tables if clean-on-uninstall option is enabled.
$clean_data = get_option( 'publication_crm_clean_on_uninstall', false );

if ( $clean_data ) {
	global $wpdb;

	$leads_table    = $wpdb->prefix . 'publication_crm_leads';
	$contacts_table = $wpdb->prefix . 'publication_crm_contacts';

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
	$wpdb->query( "DROP TABLE IF EXISTS {$leads_table}" );
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
	$wpdb->query( "DROP TABLE IF EXISTS {$contacts_table}" );

	delete_option( 'publication_crm_db_version' );
	delete_option( 'publication_crm_clean_on_uninstall' );
	delete_option( 'publication_crm_notification_email' );
	delete_option( 'publication_crm_enable_honeypot' );
}
