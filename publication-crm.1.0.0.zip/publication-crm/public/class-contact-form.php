<?php
/**
 * Frontend Contact Form Controller for Publication CRM.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Publication_CRM_Contact_Form
 */
class Publication_CRM_Contact_Form {

	/**
	 * Leads handler.
	 *
	 * @var Publication_CRM_Leads
	 */
	private $leads;

	/**
	 * Contacts handler.
	 *
	 * @var Publication_CRM_Contacts
	 */
	private $contacts;

	/**
	 * POST submission result for non-AJAX fallback.
	 *
	 * @var array|null
	 */
	private $submission_result = null;

	/**
	 * Constructor.
	 *
	 * @param Publication_CRM_Leads    $leads    Leads instance.
	 * @param Publication_CRM_Contacts $contacts Contacts instance.
	 */
	public function __construct( Publication_CRM_Leads $leads, Publication_CRM_Contacts $contacts ) {
		$this->leads    = $leads;
		$this->contacts = $contacts;

		$this->init_hooks();
	}

	/**
	 * Register actions and shortcodes.
	 */
	private function init_hooks() {
		add_shortcode( 'publication_contact_form', array( $this, 'render_shortcode' ) );

		// AJAX endpoints.
		add_action( 'wp_ajax_publication_crm_submit', array( $this, 'handle_ajax_submission' ) );
		add_action( 'wp_ajax_nopriv_publication_crm_submit', array( $this, 'handle_ajax_submission' ) );

		// Non-AJAX fallback POST handler.
		add_action( 'template_redirect', array( $this, 'handle_post_submission' ) );

		// Asset registration.
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
	}

	/**
	 * Register frontend scripts and styles.
	 */
	public function register_assets() {
		wp_register_style(
			'publication-crm-contact-form',
			PUBLICATION_CRM_URL . 'public/css/contact-form.css',
			array(),
			PUBLICATION_CRM_VERSION
		);

		wp_register_script(
			'publication-crm-contact-form',
			PUBLICATION_CRM_URL . 'public/js/contact-form.js',
			array(),
			PUBLICATION_CRM_VERSION,
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_localize_script(
			'publication-crm-contact-form',
			'publicationCrmData',
			array(
				'ajaxUrl'              => admin_url( 'admin-ajax.php' ),
				'nonce'                => wp_create_nonce( Publication_CRM_Security::NONCE_ACTION_CONTACT ),
				'submitting'           => esc_html__( 'Sending Message...', 'publication-crm' ),
				'submitBtn'            => esc_html__( 'Send Message', 'publication-crm' ),
				'genericErr'           => esc_html__( 'An unexpected error occurred. Please try again later.', 'publication-crm' ),
				'errName'              => esc_html__( 'Please enter your full name.', 'publication-crm' ),
				'errEmail'             => esc_html__( 'Please provide a valid email address.', 'publication-crm' ),
				'errEnquiry'           => esc_html__( 'Please select an enquiry category.', 'publication-crm' ),
				'errSubject'           => esc_html__( 'Please enter a subject.', 'publication-crm' ),
				'errMessage'           => esc_html__( 'Please enter your message.', 'publication-crm' ),
				'errValidationSummary' => esc_html__( 'Please resolve the highlighted errors below before submitting.', 'publication-crm' ),
			)
		);
	}

	/**
	 * Render contact form markup.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public function render_shortcode( $atts = array() ) {
		wp_enqueue_style( 'publication-crm-contact-form' );
		wp_enqueue_script( 'publication-crm-contact-form' );

		$allowed_types = Publication_CRM_Security::get_allowed_enquiry_types();
		$nonce_value   = wp_create_nonce( Publication_CRM_Security::NONCE_ACTION_CONTACT );

		$post_result = $this->submission_result;

		ob_start();
		?>
		<div class="publication-crm-form-container" id="publication-crm-wrapper">
			
			<div class="crm-form-alerts" id="crm-form-alerts" role="region" aria-live="polite">
				<?php if ( ! empty( $post_result ) ) : ?>
					<?php if ( ! empty( $post_result['success'] ) ) : ?>
						<div class="crm-alert crm-alert-success" role="alert">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="9 12 12 15 16 10"></polyline></svg>
							<span><?php echo esc_html( $post_result['message'] ); ?></span>
						</div>
					<?php else : ?>
						<div class="crm-alert crm-alert-error" role="alert">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
							<span><?php echo esc_html( $post_result['message'] ); ?></span>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</div>

			<form class="publication-crm-form" id="publication-crm-contact-form" action="<?php echo esc_url( remove_query_arg( array( 'crm_success', 'crm_error' ) ) ); ?>" method="post" novalidate>
				
				<?php wp_nonce_field( Publication_CRM_Security::NONCE_ACTION_CONTACT, Publication_CRM_Security::NONCE_NAME_CONTACT ); ?>
				
				<?php if ( '1' === get_option( 'publication_crm_enable_honeypot', '1' ) ) : ?>
					<!-- Anti-spam Honeypot Field (hidden from screen readers & visual users) -->
					<div class="crm-hp-field" style="display:none !important; position:absolute !important; left:-9999px !important;" aria-hidden="true">
						<label for="crm-hp-url"><?php esc_html_e( 'Please leave this field empty', 'publication-crm' ); ?></label>
						<input type="text" id="crm-hp-url" name="website_url_hp" tabindex="-1" autocomplete="off" />
					</div>
				<?php endif; ?>

				<div class="crm-form-grid">
					
					<!-- Full Name (Required) -->
					<div class="crm-field-group crm-col-half">
						<label for="crm-full-name" class="crm-label">
							<?php esc_html_e( 'Full Name', 'publication-crm' ); ?>
							<span class="crm-required" aria-hidden="true">*</span>
						</label>
						<input
							type="text"
							id="crm-full-name"
							name="full_name"
							class="crm-input"
							required
							aria-required="true"
							placeholder="<?php esc_attr_e( 'e.g. Eleanor Vance', 'publication-crm' ); ?>"
							autocomplete="name"
							value="<?php echo isset( $_POST['full_name'] ) && empty( $post_result['success'] ) ? esc_attr( wp_unslash( $_POST['full_name'] ) ) : ''; ?>"
						/>
						<span class="crm-field-error" id="crm-error-full-name" role="alert"></span>
					</div>

					<!-- Email Address (Required) -->
					<div class="crm-field-group crm-col-half">
						<label for="crm-email" class="crm-label">
							<?php esc_html_e( 'Email Address', 'publication-crm' ); ?>
							<span class="crm-required" aria-hidden="true">*</span>
						</label>
						<input
							type="email"
							id="crm-email"
							name="email"
							class="crm-input"
							required
							aria-required="true"
							placeholder="<?php esc_attr_e( 'name@organization.com', 'publication-crm' ); ?>"
							autocomplete="email"
							value="<?php echo isset( $_POST['email'] ) && empty( $post_result['success'] ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>"
						/>
						<span class="crm-field-error" id="crm-error-email" role="alert"></span>
					</div>

					<!-- Phone Number (Optional) -->
					<div class="crm-field-group crm-col-half">
						<label for="crm-phone" class="crm-label">
							<?php esc_html_e( 'Phone Number', 'publication-crm' ); ?>
							<span class="crm-optional"><?php esc_html_e( '(optional)', 'publication-crm' ); ?></span>
						</label>
						<input
							type="tel"
							id="crm-phone"
							name="phone"
							class="crm-input"
							placeholder="<?php esc_attr_e( '+1 (555) 000-0000', 'publication-crm' ); ?>"
							autocomplete="tel"
							value="<?php echo isset( $_POST['phone'] ) && empty( $post_result['success'] ) ? esc_attr( wp_unslash( $_POST['phone'] ) ) : ''; ?>"
						/>
					</div>

					<!-- Company / Organization (Optional) -->
					<div class="crm-field-group crm-col-half">
						<label for="crm-company" class="crm-label">
							<?php esc_html_e( 'Company / Organization', 'publication-crm' ); ?>
							<span class="crm-optional"><?php esc_html_e( '(optional)', 'publication-crm' ); ?></span>
						</label>
						<input
							type="text"
							id="crm-company"
							name="company"
							class="crm-input"
							placeholder="<?php esc_attr_e( 'Acme Corp / Media Group', 'publication-crm' ); ?>"
							autocomplete="organization"
							value="<?php echo isset( $_POST['company'] ) && empty( $post_result['success'] ) ? esc_attr( wp_unslash( $_POST['company'] ) ) : ''; ?>"
						/>
					</div>

					<!-- Enquiry Type (Required Dropdown) -->
					<div class="crm-field-group crm-col-full">
						<label for="crm-enquiry-type" class="crm-label">
							<?php esc_html_e( 'Enquiry Type', 'publication-crm' ); ?>
							<span class="crm-required" aria-hidden="true">*</span>
						</label>
						<div class="crm-select-wrapper">
							<select id="crm-enquiry-type" name="enquiry_type" class="crm-select" required aria-required="true">
								<option value=""><?php esc_html_e( '— Please Select an Enquiry Category —', 'publication-crm' ); ?></option>
								<?php
								$selected_type = isset( $_POST['enquiry_type'] ) && empty( $post_result['success'] ) ? sanitize_text_field( wp_unslash( $_POST['enquiry_type'] ) ) : '';
								foreach ( $allowed_types as $key => $label ) :
									?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $selected_type, $key ); ?>>
										<?php echo esc_html( $label ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
						<span class="crm-field-error" id="crm-error-enquiry-type" role="alert"></span>
					</div>

					<!-- Subject (Required) -->
					<div class="crm-field-group crm-col-full">
						<label for="crm-subject" class="crm-label">
							<?php esc_html_e( 'Subject', 'publication-crm' ); ?>
							<span class="crm-required" aria-hidden="true">*</span>
						</label>
						<input
							type="text"
							id="crm-subject"
							name="subject"
							class="crm-input"
							required
							aria-required="true"
							placeholder="<?php esc_attr_e( 'Brief description of your enquiry', 'publication-crm' ); ?>"
							value="<?php echo isset( $_POST['subject'] ) && empty( $post_result['success'] ) ? esc_attr( wp_unslash( $_POST['subject'] ) ) : ''; ?>"
						/>
						<span class="crm-field-error" id="crm-error-subject" role="alert"></span>
					</div>

					<!-- Message (Required) -->
					<div class="crm-field-group crm-col-full">
						<label for="crm-message" class="crm-label">
							<?php esc_html_e( 'Message', 'publication-crm' ); ?>
							<span class="crm-required" aria-hidden="true">*</span>
						</label>
						<textarea
							id="crm-message"
							name="message"
							class="crm-textarea"
							rows="6"
							required
							aria-required="true"
							placeholder="<?php esc_attr_e( 'Please provide detailed information so we can route your message to the appropriate editor or department...', 'publication-crm' ); ?>"
						><?php echo isset( $_POST['message'] ) && empty( $post_result['success'] ) ? esc_textarea( wp_unslash( $_POST['message'] ) ) : ''; ?></textarea>
						<span class="crm-field-error" id="crm-error-message" role="alert"></span>
					</div>

				</div>

				<!-- Form Actions -->
				<div class="crm-form-actions">
					<button type="submit" class="crm-submit-btn" id="crm-submit-btn">
						<span class="crm-btn-text"><?php esc_html_e( 'Send Message', 'publication-crm' ); ?></span>
						<span class="crm-btn-spinner" aria-hidden="true"></span>
					</button>
				</div>

			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Handle AJAX form submission.
	 */
	public function handle_ajax_submission() {
		// Verify Nonce.
		if ( ! check_ajax_referer( Publication_CRM_Security::NONCE_ACTION_CONTACT, 'nonce', false ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Security verification failed. Please refresh the page and try again.', 'publication-crm' ),
				),
				403
			);
		}

		$sanitized_or_error = Publication_CRM_Security::validate_and_sanitize_lead_input( $_POST );

		if ( is_wp_error( $sanitized_or_error ) ) {
			wp_send_json_error(
				array(
					'message' => $sanitized_or_error->get_error_message(),
					'errors'  => $sanitized_or_error->get_error_messages(),
				),
				400
			);
		}

		$lead_id = $this->leads->create_lead( $sanitized_or_error );

		if ( ! $lead_id ) {
			wp_send_json_error(
				array(
					'message' => __( 'We were unable to save your message due to an internal error. Please try again later.', 'publication-crm' ),
				),
				500
			);
		}

		// Also sync or create contact record.
		$this->contacts->sync_from_lead( $sanitized_or_error );

		// Dispatch email notification to administrator.
		$this->send_notification_email( $sanitized_or_error, $lead_id );

		wp_send_json_success(
			array(
				'message' => __( 'Thank you! Your message has been sent successfully. Our editorial and business team will review your enquiry shortly.', 'publication-crm' ),
				'lead_id' => $lead_id,
			)
		);
	}

	/**
	 * Handle standard POST submission fallback (if JS disabled).
	 */
	public function handle_post_submission() {
		if ( 'POST' !== $_SERVER['REQUEST_METHOD'] || empty( $_POST[ Publication_CRM_Security::NONCE_NAME_CONTACT ] ) ) {
			return;
		}

		// Verify Nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ Publication_CRM_Security::NONCE_NAME_CONTACT ] ) ), Publication_CRM_Security::NONCE_ACTION_CONTACT ) ) {
			$this->submission_result = array(
				'success' => false,
				'message' => __( 'Security validation failed. Please reload the page and submit again.', 'publication-crm' ),
			);
			return;
		}

		$sanitized_or_error = Publication_CRM_Security::validate_and_sanitize_lead_input( $_POST );

		if ( is_wp_error( $sanitized_or_error ) ) {
			$this->submission_result = array(
				'success' => false,
				'message' => $sanitized_or_error->get_error_message(),
			);
			return;
		}

		$lead_id = $this->leads->create_lead( $sanitized_or_error );

		if ( ! $lead_id ) {
			$this->submission_result = array(
				'success' => false,
				'message' => __( 'We were unable to save your message due to a server error. Please try again.', 'publication-crm' ),
			);
			return;
		}

		$this->contacts->sync_from_lead( $sanitized_or_error );

		// Dispatch email notification to administrator.
		$this->send_notification_email( $sanitized_or_error, $lead_id );

		$this->submission_result = array(
			'success' => true,
			'message' => __( 'Thank you! Your message has been sent successfully. Our editorial and business team will review your enquiry shortly.', 'publication-crm' ),
		);
	}

	/**
	 * Send immediate notification email to the configured administrator.
	 *
	 * @param array $lead_data Lead submission data.
	 * @param int   $lead_id   Created lead ID.
	 * @return bool Whether the email was sent successfully.
	 */
	public function send_notification_email( array $lead_data, $lead_id ) {
		$recipient = get_option( 'publication_crm_notification_email', get_option( 'admin_email' ) );

		if ( empty( $recipient ) || ! is_email( $recipient ) ) {
			return false;
		}

		$blogname = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );

		/* translators: 1: site name, 2: enquiry subject */
		$subject = sprintf( __( '[%1$s CRM] New Lead: %2$s', 'publication-crm' ), $blogname, $lead_data['subject'] );

		$lead_admin_url = admin_url( 'admin.php?page=publication-crm-leads&action=view&id=' . absint( $lead_id ) );

		/* translators: %s: site name */
		$message  = sprintf( __( "A new website inquiry has been submitted on %s.\n\n", 'publication-crm' ), $blogname );
		/* translators: %d: lead ID */
		$message .= sprintf( __( "Lead ID: #%d\n", 'publication-crm' ), absint( $lead_id ) );
		/* translators: %s: lead full name */
		$message .= sprintf( __( "Full Name: %s\n", 'publication-crm' ), $lead_data['full_name'] );
		/* translators: %s: lead email */
		$message .= sprintf( __( "Email: %s\n", 'publication-crm' ), $lead_data['email'] );
		/* translators: %s: lead phone */
		$message .= sprintf( __( "Phone: %s\n", 'publication-crm' ), ! empty( $lead_data['phone'] ) ? $lead_data['phone'] : __( 'N/A', 'publication-crm' ) );
		/* translators: %s: lead company */
		$message .= sprintf( __( "Company / Org: %s\n", 'publication-crm' ), ! empty( $lead_data['company'] ) ? $lead_data['company'] : __( 'N/A', 'publication-crm' ) );
		/* translators: %s: enquiry type */
		$message .= sprintf( __( "Enquiry Type: %s\n", 'publication-crm' ), $lead_data['enquiry_type'] );
		/* translators: %s: enquiry subject */
		$message .= sprintf( __( "Subject: %s\n\n", 'publication-crm' ), $lead_data['subject'] );
		$message .= __( "Message:\n", 'publication-crm' );
		$message .= "----------------------------------------\n";
		$message .= $lead_data['message'] . "\n";
		$message .= "----------------------------------------\n\n";
		/* translators: %s: admin lead URL */
		$message .= sprintf( __( "View & Manage Lead in Admin:\n%s\n", 'publication-crm' ), $lead_admin_url );

		$headers = array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . sanitize_text_field( $lead_data['full_name'] ) . ' <' . sanitize_email( $lead_data['email'] ) . '>',
		);

		return wp_mail( $recipient, $subject, $message, $headers );
	}
}
