/**
 * Publication CRM - Accessible Contact Form JavaScript
 * 
 * Vanilla ES6, zero external dependencies, accessible feedback.
 */
(function() {
  'use strict';

  function initContactForm() {
    var form = document.getElementById('publication-crm-contact-form');
    if (!form) return;

    var alertsContainer = document.getElementById('crm-form-alerts');
    var submitBtn = document.getElementById('crm-submit-btn');
    var btnText = submitBtn ? submitBtn.querySelector('.crm-btn-text') : null;

    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    function clearErrors() {
      var errorGroups = form.querySelectorAll('.crm-field-group.has-error');
      errorGroups.forEach(function(group) {
        group.classList.remove('has-error');
        var errorMsg = group.querySelector('.crm-field-error');
        if (errorMsg) {
          errorMsg.textContent = '';
        }
      });
      if (alertsContainer) {
        alertsContainer.innerHTML = '';
      }
    }

    function showFieldError(fieldId, errorElementId, message) {
      var field = document.getElementById(fieldId);
      var group = field ? field.closest('.crm-field-group') : null;
      var errEl = document.getElementById(errorElementId);

      if (group && errEl) {
        group.classList.add('has-error');
        errEl.textContent = message;
      }
    }

    function showAlert(type, message) {
      if (!alertsContainer) return;

      var alertDiv = document.createElement('div');
      alertDiv.className = 'crm-alert crm-alert-' + (type === 'success' ? 'success' : 'error');
      alertDiv.setAttribute('role', 'alert');

      var iconSvg = type === 'success'
        ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="9 12 12 15 16 10"></polyline></svg>'
        : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';

      alertDiv.innerHTML = iconSvg + '<span>' + message + '</span>';
      alertsContainer.innerHTML = '';
      alertsContainer.appendChild(alertDiv);

      alertsContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      clearErrors();

      var hasError = false;

      var crmStrings = window.publicationCrmData || {};

      // Validate Full Name
      var fullNameInput = document.getElementById('crm-full-name');
      if (!fullNameInput || !fullNameInput.value.trim()) {
        showFieldError('crm-full-name', 'crm-error-full-name', crmStrings.errName || 'Please enter your full name.');
        hasError = true;
      }

      // Validate Email
      var emailInput = document.getElementById('crm-email');
      if (!emailInput || !emailInput.value.trim() || !emailRegex.test(emailInput.value.trim())) {
        showFieldError('crm-email', 'crm-error-email', crmStrings.errEmail || 'Please provide a valid email address.');
        hasError = true;
      }

      // Validate Enquiry Type
      var enquiryTypeSelect = document.getElementById('crm-enquiry-type');
      if (!enquiryTypeSelect || !enquiryTypeSelect.value) {
        showFieldError('crm-enquiry-type', 'crm-error-enquiry-type', crmStrings.errEnquiry || 'Please select an enquiry category.');
        hasError = true;
      }

      // Validate Subject
      var subjectInput = document.getElementById('crm-subject');
      if (!subjectInput || !subjectInput.value.trim()) {
        showFieldError('crm-subject', 'crm-error-subject', crmStrings.errSubject || 'Please enter a subject.');
        hasError = true;
      }

      // Validate Message
      var messageInput = document.getElementById('crm-message');
      if (!messageInput || !messageInput.value.trim()) {
        showFieldError('crm-message', 'crm-error-message', crmStrings.errMessage || 'Please enter your message.');
        hasError = true;
      }

      if (hasError) {
        showAlert('error', crmStrings.errValidationSummary || 'Please resolve the highlighted errors below before submitting.');
        return;
      }

      // Prepare Submission
      var formData = new FormData(form);
      formData.append('action', 'publication_crm_submit');
      if (window.publicationCrmData && window.publicationCrmData.nonce) {
        formData.append('nonce', window.publicationCrmData.nonce);
      }

      // Set Loading State
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.classList.add('is-loading');
      }
      if (btnText && window.publicationCrmData) {
        btnText.textContent = window.publicationCrmData.submitting;
      }

      var ajaxUrl = (window.publicationCrmData && window.publicationCrmData.ajaxUrl) ? window.publicationCrmData.ajaxUrl : '/wp-admin/admin-ajax.php';

      fetch(ajaxUrl, {
        method: 'POST',
        body: formData
      })
      .then(function(response) {
        return response.json();
      })
      .then(function(data) {
        if (data.success) {
          showAlert('success', data.data.message);
          form.reset();
        } else {
          var errorMsg = (data.data && data.data.message) ? data.data.message : (window.publicationCrmData ? window.publicationCrmData.genericErr : 'An error occurred.');
          showAlert('error', errorMsg);
        }
      })
      .catch(function(error) {
        var genericMsg = (window.publicationCrmData && window.publicationCrmData.genericErr) ? window.publicationCrmData.genericErr : 'An unexpected error occurred. Please try again.';
        showAlert('error', genericMsg);
      })
      .finally(function() {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('is-loading');
        }
        if (btnText && window.publicationCrmData) {
          btnText.textContent = window.publicationCrmData.submitBtn;
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initContactForm);
  } else {
    initContactForm();
  }
})();
