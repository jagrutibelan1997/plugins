<?php
/**
 * CRM Settings View.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$notification_email = get_option( 'publication_crm_notification_email', get_option( 'admin_email' ) );
$enable_honeypot    = get_option( 'publication_crm_enable_honeypot', '1' );
$clean_uninstall    = get_option( 'publication_crm_clean_on_uninstall', '0' );
?>

<div class="wrap crm-admin-wrap">
	<div class="crm-header-bar">
		<h1><?php esc_html_e( 'CRM Settings', 'publication-crm' ); ?></h1>
	</div>

	<?php if ( isset( $_GET['settings_updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Settings saved successfully.', 'publication-crm' ); ?></p>
		</div>
	<?php endif; ?>

	<div class="crm-panel" style="max-width: 720px;">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-settings&action=save_settings' ) ); ?>">
			<?php wp_nonce_field( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' ); ?>

			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">
							<label for="crm_notification_email"><?php esc_html_e( 'Notification Email', 'publication-crm' ); ?></label>
						</th>
						<td>
							<input
								name="publication_crm_notification_email"
								type="email"
								id="crm_notification_email"
								value="<?php echo esc_attr( $notification_email ); ?>"
								class="regular-text"
							/>
							<p class="description">
								<?php esc_html_e( 'Email address to receive immediate lead alerts when a visitor submits the contact form.', 'publication-crm' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Anti-Spam Honeypot', 'publication-crm' ); ?></th>
						<td>
							<label for="crm_enable_honeypot">
								<input
									name="publication_crm_enable_honeypot"
									type="checkbox"
									id="crm_enable_honeypot"
									value="1"
									<?php checked( '1', $enable_honeypot ); ?>
								/>
								<?php esc_html_e( 'Enable silent honeypot field protection on public contact form', 'publication-crm' ); ?>
							</label>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Uninstall Cleanup', 'publication-crm' ); ?></th>
						<td>
							<label for="crm_clean_on_uninstall">
								<input
									name="publication_crm_clean_on_uninstall"
									type="checkbox"
									id="crm_clean_on_uninstall"
									value="1"
									<?php checked( '1', $clean_uninstall ); ?>
								/>
								<span style="color: #b91c1c;">
									<?php esc_html_e( 'Drop custom CRM database tables if plugin is deleted via Plugins screen (Warning: Deletes all lead records)', 'publication-crm' ); ?>
								</span>
							</label>
						</td>
					</tr>
				</tbody>
			</table>

			<p class="submit">
				<input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Settings', 'publication-crm' ); ?>">
			</p>
		</form>
	</div>
</div>
