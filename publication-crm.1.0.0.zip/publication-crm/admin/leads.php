<?php
/**
 * CRM Leads List View.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$search       = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$status       = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
$enquiry_type = isset( $_GET['enquiry_type'] ) ? sanitize_text_field( wp_unslash( $_GET['enquiry_type'] ) ) : '';
$paged        = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
$per_page     = 15;

$result = $this->leads->get_leads(
	array(
		'search'       => $search,
		'status'       => $status,
		'enquiry_type' => $enquiry_type,
		'paged'        => $paged,
		'per_page'     => $per_page,
		'orderby'      => 'created_at',
		'order'        => 'DESC',
	)
);

$leads       = $result['items'];
$total       = $result['total'];
$total_pages = $result['pages'];

$allowed_statuses = Publication_CRM_Security::get_allowed_statuses();
$allowed_types    = Publication_CRM_Security::get_allowed_enquiry_types();
?>

<div class="wrap crm-admin-wrap">
	<div class="crm-header-bar">
		<h1>
			<?php esc_html_e( 'CRM Leads', 'publication-crm' ); ?>
			<span class="count" style="font-size: 14px; font-weight: normal; color: #64748b;">(<?php echo esc_html( number_format_i18n( $total ) ); ?>)</span>
		</h1>
	</div>

	<?php if ( isset( $_GET['deleted'] ) ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Lead was deleted successfully.', 'publication-crm' ); ?></p>
		</div>
	<?php endif; ?>

	<!-- Filters & Search Toolbar -->
	<div class="crm-toolbar">
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="crm-filter-form">
			<input type="hidden" name="page" value="publication-crm-leads" />

			<!-- Search -->
			<input
				type="search"
				name="s"
				value="<?php echo esc_attr( $search ); ?>"
				placeholder="<?php esc_attr_e( 'Search by name, email, company...', 'publication-crm' ); ?>"
				style="width: 250px;"
			/>

			<!-- Status Filter -->
			<select name="status">
				<option value=""><?php esc_html_e( 'All Statuses', 'publication-crm' ); ?></option>
				<?php foreach ( $allowed_statuses as $st_key => $st_label ) : ?>
					<option value="<?php echo esc_attr( $st_key ); ?>" <?php selected( $status, $st_key ); ?>>
						<?php echo esc_html( $st_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>

			<!-- Enquiry Type Filter -->
			<select name="enquiry_type">
				<option value=""><?php esc_html_e( 'All Enquiry Types', 'publication-crm' ); ?></option>
				<?php foreach ( $allowed_types as $type_key => $type_label ) : ?>
					<option value="<?php echo esc_attr( $type_key ); ?>" <?php selected( $enquiry_type, $type_key ); ?>>
						<?php echo esc_html( $type_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>

			<button type="submit" class="button button-secondary">
				<?php esc_html_e( 'Filter', 'publication-crm' ); ?>
			</button>

			<?php if ( ! empty( $search ) || ! empty( $status ) || ! empty( $enquiry_type ) ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>" class="button button-link">
					<?php esc_html_e( 'Reset Filters', 'publication-crm' ); ?>
				</a>
			<?php endif; ?>
		</form>

		<div class="crm-pagination-summary" style="font-size: 13px; color: #64748b;">
			<?php
			/* translators: 1: current page number, 2: total pages */
			printf( esc_html__( 'Page %1$d of %2$d', 'publication-crm' ), absint( $paged ), absint( max( 1, $total_pages ) ) );
			?>
		</div>
	</div>

	<!-- Leads Table -->
	<?php if ( empty( $leads ) ) : ?>
		<div class="crm-panel">
			<p style="color: #64748b; font-style: italic; margin: 0;">
				<?php esc_html_e( 'No leads found matching your criteria.', 'publication-crm' ); ?>
			</p>
		</div>
	<?php else : ?>
		<table class="wp-list-table widefat fixed striped table-view-list">
			<thead>
				<tr>
					<th scope="col" style="width: 18%;"><?php esc_html_e( 'Name', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 20%;"><?php esc_html_e( 'Email', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 14%;"><?php esc_html_e( 'Company', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 14%;"><?php esc_html_e( 'Enquiry Type', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 8%;"><?php esc_html_e( 'Source', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 10%;"><?php esc_html_e( 'Status', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 12%;"><?php esc_html_e( 'Created', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 10%;"><?php esc_html_e( 'Actions', 'publication-crm' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $leads as $lead ) : ?>
					<tr>
						<td>
							<strong>
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=view&id=' . $lead->id ) ); ?>">
									<?php echo esc_html( $lead->full_name ); ?>
								</a>
							</strong>
						</td>
						<td>
							<a href="mailto:<?php echo esc_attr( $lead->email ); ?>">
								<?php echo esc_html( $lead->email ); ?>
							</a>
						</td>
						<td><?php echo esc_html( $lead->company ? $lead->company : '—' ); ?></td>
						<td>
							<span class="crm-badge crm-badge-enquiry">
								<?php echo esc_html( $lead->enquiry_type ); ?>
							</span>
						</td>
						<td><?php echo esc_html( $lead->source ); ?></td>
						<td>
							<span class="crm-badge crm-badge-<?php echo esc_attr( strtolower( $lead->status ) ); ?>">
								<?php echo esc_html( $lead->status ); ?>
							</span>
						</td>
						<td>
							<abbr title="<?php echo esc_attr( $lead->created_at ); ?>">
								<?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $lead->created_at ) ) ); ?>
							</abbr>
						</td>
						<td>
							<div class="row-actions visible" style="display: flex; gap: 8px; align-items: center;">
								<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=view&id=' . $lead->id ) ); ?>" class="button button-small">
									<?php esc_html_e( 'View', 'publication-crm' ); ?>
								</a>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=delete' ) ); ?>" class="crm-confirm-delete" style="display: inline; margin: 0;" data-confirm="<?php echo esc_attr__( 'Are you sure you want to delete this lead record?', 'publication-crm' ); ?>">
									<?php wp_nonce_field( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' ); ?>
									<input type="hidden" name="id" value="<?php echo esc_attr( $lead->id ); ?>" />
									<button type="submit" class="button button-small button-link-delete" style="color: #b91c1c; cursor: pointer;">
										<?php esc_html_e( 'Delete', 'publication-crm' ); ?>
									</button>
								</form>
							</div>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<!-- Pagination Navigation -->
		<?php if ( $total_pages > 1 ) : ?>
			<div class="tablenav bottom" style="margin-top: 16px;">
				<div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'prev_text' => __( '&laquo; Prev', 'publication-crm' ),
								'next_text' => __( 'Next &raquo;', 'publication-crm' ),
								'total'     => $total_pages,
								'current'   => $paged,
							)
						)
					);
					?>
				</div>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
