/**
 * Publication CRM Admin JavaScript
 *
 * @package Publication_CRM
 */
(function() {
	'use strict';

	document.addEventListener('DOMContentLoaded', function() {
		document.addEventListener('submit', function(e) {
			var form = e.target;
			if (form && form.classList.contains('crm-confirm-delete')) {
				var msg = form.getAttribute('data-confirm') || 'Are you sure you want to delete this record?';
				if (!window.confirm(msg)) {
					e.preventDefault();
				}
			}
		});
	});
})();
