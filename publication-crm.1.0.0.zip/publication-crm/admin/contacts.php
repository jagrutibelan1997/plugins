<?php
/**
 * CRM Contacts Directory View.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
$per_page = 20;

$result = $this->contacts->get_contacts(
	array(
		'search'   => $search,
		'paged'    => $paged,
		'per_page' => $per_page,
		'orderby'  => 'created_at',
		'order'    => 'DESC',
	)
);

$contacts    = $result['items'];
$total       = $result['total'];
$total_pages = $result['pages'];
?>

<div class="wrap crm-admin-wrap">
	<div class="crm-header-bar">
		<h1>
			<?php esc_html_e( 'CRM Contacts Directory', 'publication-crm' ); ?>
			<span class="count" style="font-size: 14px; font-weight: normal; color: #64748b;">(<?php echo esc_html( number_format_i18n( $total ) ); ?>)</span>
		</h1>
	</div>

	<!-- Toolbar -->
	<div class="crm-toolbar">
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="crm-filter-form">
			<input type="hidden" name="page" value="publication-crm-contacts" />

			<input
				type="search"
				name="s"
				value="<?php echo esc_attr( $search ); ?>"
				placeholder="<?php esc_attr_e( 'Search contacts by name, email, company...', 'publication-crm' ); ?>"
				style="width: 280px;"
			/>

			<button type="submit" class="button button-secondary">
				<?php esc_html_e( 'Search Contacts', 'publication-crm' ); ?>
			</button>

			<?php if ( ! empty( $search ) ) : ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-contacts' ) ); ?>" class="button button-link">
					<?php esc_html_e( 'Reset', 'publication-crm' ); ?>
				</a>
			<?php endif; ?>
		</form>

		<div class="crm-pagination-summary" style="font-size: 13px; color: #64748b;">
			<?php
			/* translators: 1: current page number, 2: total pages */
			printf( esc_html__( 'Page %1$d of %2$d', 'publication-crm' ), absint( $paged ), absint( max( 1, $total_pages ) ) );
			?>
		</div>
	</div>

	<!-- Contacts Table -->
	<?php if ( empty( $contacts ) ) : ?>
		<div class="crm-panel">
			<p style="color: #64748b; font-style: italic; margin: 0;">
				<?php esc_html_e( 'No contacts registered in the system yet.', 'publication-crm' ); ?>
			</p>
		</div>
	<?php else : ?>
		<table class="wp-list-table widefat fixed striped table-view-list">
			<thead>
				<tr>
					<th scope="col" style="width: 22%;"><?php esc_html_e( 'Contact Name', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 25%;"><?php esc_html_e( 'Email', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 18%;"><?php esc_html_e( 'Phone', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 18%;"><?php esc_html_e( 'Company', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 10%;"><?php esc_html_e( 'Total Enquiries', 'publication-crm' ); ?></th>
					<th scope="col" style="width: 12%;"><?php esc_html_e( 'Created', 'publication-crm' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $contacts as $contact ) : ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $contact->full_name ? $contact->full_name : '—' ); ?></strong>
						</td>
						<td>
							<a href="mailto:<?php echo esc_attr( $contact->email ); ?>">
								<?php echo esc_html( $contact->email ); ?>
							</a>
						</td>
						<td><?php echo esc_html( $contact->phone ? $contact->phone : '—' ); ?></td>
						<td><?php echo esc_html( $contact->company ? $contact->company : '—' ); ?></td>
						<td>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&s=' . urlencode( $contact->email ) ) ); ?>" class="crm-badge crm-badge-enquiry" style="text-decoration: none;">
								<?php echo esc_html( number_format_i18n( $contact->total_leads ) ); ?>
							</a>
						</td>
						<td>
							<?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $contact->created_at ) ) ); ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<!-- Pagination Navigation -->
		<?php if ( $total_pages > 1 ) : ?>
			<div class="tablenav bottom" style="margin-top: 16px;">
				<div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'prev_text' => __( '&laquo; Prev', 'publication-crm' ),
								'next_text' => __( 'Next &raquo;', 'publication-crm' ),
								'total'     => $total_pages,
								'current'   => $paged,
							)
						)
					);
					?>
				</div>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
