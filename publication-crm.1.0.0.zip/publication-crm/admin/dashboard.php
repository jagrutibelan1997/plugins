<?php
/**
 * CRM Dashboard View.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$counts       = $this->leads->get_counts_by_status();
$recent_leads = $this->leads->get_recent_leads( 8 );
$total_contacts = $this->contacts->get_total_count();
?>

<div class="wrap crm-admin-wrap">
	<div class="crm-header-bar">
		<h1><?php esc_html_e( 'CRM Dashboard', 'publication-crm' ); ?></h1>
		<div class="crm-header-actions">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>" class="button button-primary">
				<?php esc_html_e( 'Manage Leads', 'publication-crm' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-contacts' ) ); ?>" class="button">
				<?php esc_html_e( 'View Contacts Directory', 'publication-crm' ); ?>
			</a>
		</div>
	</div>

	<!-- Statistics Cards -->
	<div class="crm-stats-grid">
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>" class="crm-stat-card stat-total">
			<span class="crm-stat-label"><?php esc_html_e( 'Total Leads', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['Total'] ) ); ?></span>
		</a>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&status=New' ) ); ?>" class="crm-stat-card stat-new">
			<span class="crm-stat-label"><?php esc_html_e( 'New Leads', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['New'] ) ); ?></span>
		</a>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&status=Contacted' ) ); ?>" class="crm-stat-card stat-contacted">
			<span class="crm-stat-label"><?php esc_html_e( 'Contacted', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['Contacted'] ) ); ?></span>
		</a>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&status=Qualified' ) ); ?>" class="crm-stat-card stat-qualified">
			<span class="crm-stat-label"><?php esc_html_e( 'Qualified', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['Qualified'] ) ); ?></span>
		</a>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&status=Converted' ) ); ?>" class="crm-stat-card stat-converted">
			<span class="crm-stat-label"><?php esc_html_e( 'Converted', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['Converted'] ) ); ?></span>
		</a>

		<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&status=Lost' ) ); ?>" class="crm-stat-card stat-lost">
			<span class="crm-stat-label"><?php esc_html_e( 'Lost', 'publication-crm' ); ?></span>
			<span class="crm-stat-value"><?php echo esc_html( number_format_i18n( $counts['Lost'] ) ); ?></span>
		</a>
	</div>

	<!-- Recent Inquiries Panel -->
	<div class="crm-panel">
		<div class="crm-panel-header">
			<h2><?php esc_html_e( 'Recent Website Inquiries', 'publication-crm' ); ?></h2>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>">
				<?php esc_html_e( 'View All Leads →', 'publication-crm' ); ?>
			</a>
		</div>

		<?php if ( empty( $recent_leads ) ) : ?>
			<p style="color: #64748b; font-style: italic;"><?php esc_html_e( 'No leads received yet. Submit a message from the /contact/ page to see it here.', 'publication-crm' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width: 20%;"><?php esc_html_e( 'Name', 'publication-crm' ); ?></th>
						<th style="width: 22%;"><?php esc_html_e( 'Email', 'publication-crm' ); ?></th>
						<th style="width: 18%;"><?php esc_html_e( 'Company', 'publication-crm' ); ?></th>
						<th style="width: 15%;"><?php esc_html_e( 'Enquiry Type', 'publication-crm' ); ?></th>
						<th style="width: 12%;"><?php esc_html_e( 'Status', 'publication-crm' ); ?></th>
						<th style="width: 13%;"><?php esc_html_e( 'Received', 'publication-crm' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $recent_leads as $lead ) : ?>
						<tr>
							<td>
								<strong>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=view&id=' . $lead->id ) ); ?>">
										<?php echo esc_html( $lead->full_name ); ?>
									</a>
								</strong>
							</td>
							<td>
								<a href="mailto:<?php echo esc_attr( $lead->email ); ?>">
									<?php echo esc_html( $lead->email ); ?>
								</a>
							</td>
							<td><?php echo esc_html( $lead->company ? $lead->company : '—' ); ?></td>
							<td>
								<span class="crm-badge crm-badge-enquiry">
									<?php echo esc_html( $lead->enquiry_type ); ?>
								</span>
							</td>
							<td>
								<span class="crm-badge crm-badge-<?php echo esc_attr( strtolower( $lead->status ) ); ?>">
									<?php echo esc_html( $lead->status ); ?>
								</span>
							<td>
								<?php
								printf(
									/* translators: %s: Human-readable time difference, e.g. 2 hours. */
									esc_html__( '%s ago', 'publication-crm' ),
									esc_html( human_time_diff( strtotime( $lead->created_at ), time() ) )
								);
								?>
							</td>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</div>
