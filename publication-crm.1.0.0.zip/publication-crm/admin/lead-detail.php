<?php
/**
 * CRM Lead Detail View.
 *
 * @package Publication_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$lead_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
$lead    = $this->leads->get_lead( $lead_id );

if ( ! $lead ) {
	?>
	<div class="wrap crm-admin-wrap">
		<h1><?php esc_html_e( 'Lead Not Found', 'publication-crm' ); ?></h1>
		<p><?php esc_html_e( 'The requested lead record could not be found or has been removed.', 'publication-crm' ); ?></p>
		<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>" class="button button-primary"><?php esc_html_e( '← Back to Leads', 'publication-crm' ); ?></a></p>
	</div>
	<?php
	return;
}

$allowed_statuses = Publication_CRM_Security::get_allowed_statuses();
?>

<div class="wrap crm-admin-wrap">
	<div class="crm-header-bar">
		<div>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads' ) ); ?>" style="text-decoration: none; font-size: 13px; font-weight: 600; color: #2563eb; display: inline-block; margin-bottom: 6px;">
				<?php esc_html_e( '← Back to Leads', 'publication-crm' ); ?>
			</a>
			<h1><?php printf( esc_html__( 'Lead #%1$d: %2$s', 'publication-crm' ), absint( $lead->id ), esc_html( $lead->full_name ) ); ?></h1>
		</div>
		<div>
			<span class="crm-badge crm-badge-<?php echo esc_attr( strtolower( $lead->status ) ); ?>" style="font-size: 13px; padding: 6px 14px;">
				<?php echo esc_html( $lead->status ); ?>
			</span>
		</div>
	</div>

	<?php if ( isset( $_GET['updated'] ) ) : ?>
		<div class="notice notice-success is-dismissible">
			<p><?php esc_html_e( 'Lead status was updated successfully.', 'publication-crm' ); ?></p>
		</div>
	<?php endif; ?>

	<div class="crm-detail-grid">
		<!-- Left Main Column: Contact Info & Enquiry -->
		<div>
			
			<!-- Contact Information Card -->
			<div class="crm-panel">
				<div class="crm-panel-header">
					<h2><?php esc_html_e( 'Contact Information', 'publication-crm' ); ?></h2>
				</div>
				<div class="crm-info-list">
					<div class="crm-info-label"><?php esc_html_e( 'Full Name', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value"><strong><?php echo esc_html( $lead->full_name ); ?></strong></div>

					<div class="crm-info-label"><?php esc_html_e( 'Email Address', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value">
						<a href="mailto:<?php echo esc_attr( $lead->email ); ?>"><?php echo esc_html( $lead->email ); ?></a>
					</div>

					<div class="crm-info-label"><?php esc_html_e( 'Phone Number', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value">
						<?php if ( ! empty( $lead->phone ) ) : ?>
							<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $lead->phone ) ); ?>"><?php echo esc_html( $lead->phone ); ?></a>
						<?php else : ?>
							<span style="color: #94a3b8; font-style: italic;"><?php esc_html_e( 'Not provided', 'publication-crm' ); ?></span>
						<?php endif; ?>
					</div>

					<div class="crm-info-label"><?php esc_html_e( 'Company / Org', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value">
						<?php echo esc_html( ! empty( $lead->company ) ? $lead->company : '—' ); ?>
					</div>
				</div>
			</div>

			<!-- Enquiry Details Card -->
			<div class="crm-panel">
				<div class="crm-panel-header">
					<h2><?php esc_html_e( 'Enquiry Details', 'publication-crm' ); ?></h2>
					<span class="crm-badge crm-badge-enquiry"><?php echo esc_html( $lead->enquiry_type ); ?></span>
				</div>
				
				<div style="margin-bottom: 16px;">
					<div class="crm-info-label" style="margin-bottom: 4px;"><?php esc_html_e( 'Subject', 'publication-crm' ); ?>:</div>
					<div style="font-size: 16px; font-weight: 700; color: #0f172a;">
						<?php echo esc_html( $lead->subject ); ?>
					</div>
				</div>

				<div>
					<div class="crm-info-label" style="margin-bottom: 6px;"><?php esc_html_e( 'Message Body', 'publication-crm' ); ?>:</div>
					<div class="crm-message-box"><?php echo esc_html( $lead->message ); ?></div>
				</div>
			</div>

		</div>

		<!-- Right Column: Lead Metadata & Status Control -->
		<div>
			
			<div class="crm-panel">
				<div class="crm-panel-header">
					<h2><?php esc_html_e( 'Lead Information', 'publication-crm' ); ?></h2>
				</div>
				
				<div class="crm-info-list" style="grid-template-columns: 100px 1fr;">
					<div class="crm-info-label"><?php esc_html_e( 'Source', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value"><strong><?php echo esc_html( $lead->source ); ?></strong></div>

					<div class="crm-info-label"><?php esc_html_e( 'Current Status', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value">
						<span class="crm-badge crm-badge-<?php echo esc_attr( strtolower( $lead->status ) ); ?>">
							<?php echo esc_html( $lead->status ); ?>
						</span>
					</div>

					<div class="crm-info-label"><?php esc_html_e( 'Created Date', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value"><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $lead->created_at ) ) ); ?></div>

					<div class="crm-info-label"><?php esc_html_e( 'Updated Date', 'publication-crm' ); ?>:</div>
					<div class="crm-info-value"><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $lead->updated_at ) ) ); ?></div>
				</div>

				<!-- Status Update Form -->
				<div class="crm-status-box">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=update_status' ) ); ?>">
						<?php wp_nonce_field( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' ); ?>
						<input type="hidden" name="lead_id" value="<?php echo esc_attr( $lead->id ); ?>" />

						<label for="lead-status-select"><?php esc_html_e( 'Change Lead Status', 'publication-crm' ); ?></label>
						<select id="lead-status-select" name="new_status">
							<?php foreach ( $allowed_statuses as $st_key => $st_label ) : ?>
								<option value="<?php echo esc_attr( $st_key ); ?>" <?php selected( $lead->status, $st_key ); ?>>
									<?php echo esc_html( $st_label ); ?>
								</option>
							<?php endforeach; ?>
						</select>

						<button type="submit" class="button button-primary">
							<?php esc_html_e( 'Update Status', 'publication-crm' ); ?>
						</button>
					</form>
				</div>

				<div style="margin-top: 20px; padding-top: 16px; border-top: 1px solid #f1f5f9; text-align: center;">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=publication-crm-leads&action=delete' ) ); ?>" class="crm-confirm-delete" data-confirm="<?php echo esc_attr__( 'Are you sure you want to permanently delete this lead?', 'publication-crm' ); ?>">
						<?php wp_nonce_field( Publication_CRM_Security::NONCE_ACTION_ADMIN, 'crm_admin_nonce' ); ?>
						<input type="hidden" name="id" value="<?php echo esc_attr( $lead->id ); ?>" />
						<button type="submit" style="color: #dc2626; font-size: 13px; background: none; border: none; cursor: pointer; text-decoration: underline; padding: 0;">
							<?php esc_html_e( 'Delete this lead record', 'publication-crm' ); ?>
						</button>
					</form>
				</div>
			</div>

		</div>
	</div>
</div>
